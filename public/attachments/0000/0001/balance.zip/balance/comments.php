<?php
        if (strstr($_SERVER['HTTP_USER_AGENT'], "MSIE")) {$ie=TRUE;}
?>
<?php // Do not delete these lines
	if ('comments.php' == basename($_SERVER['SCRIPT_FILENAME']))
		die ('Please do not load this page directly. Thanks!');

        if (!empty($post->post_password)) { // if there's a password
            if ($_COOKIE['wp-postpass_' . COOKIEHASH] != $post->post_password) {  // and it doesn't match the cookie
				?>
				
				<p class="nocomments"><?php _e("This post is password protected. Enter the password to view comments."); ?><p>
				
				<?php
				return;
            }
        }
?>

<?php

/* Function for seperating comments from track- and pingbacks. */
                function k2_comment_type_detection($commenttxt = 'Comment', $trackbacktxt = 'Trackback', $pingbacktxt = 'Pingback') {
                        global $comment;
                        if (preg_match('|trackback|', $comment->comment_type))
                                return $trackbacktxt;
                        elseif (preg_match('|pingback|', $comment->comment_type))
                                return $pingbacktxt;
                        else
                                return $commenttxt;
                }
?>

<!-- You can start editing here. -->

<div class="comments" id="comments">
<ol class="commentlist" id="commentlist">

<?php if ($comments) : ?>
<div style="float:right;">
<h3><a href="<?php the_permalink(); ?>feed/"><img src="/wp-content/themes/balance/images/rss_small.png" style="border:0px;" alt="" /></a></h3>
</div>
	<h2 style="margin-bottom:40px;" id="comments" style=''><?php comments_number('No Responses', 'One Response', '% Responses' );?> to &#8220;<?php the_title(); ?>&#8221;</h2>

	<?php foreach ($comments as $comment) : ?>
	 <?php if (k2_comment_type_detection() != "Comment" ) {continue;} ?>

		<a name="comment-<?php comment_ID() ?>"></a>
		<li class="norm" id="comment-<?php comment_ID() ?>">
			<img src='<?php gravatar("X", 25, "http://www.thoughtmechanics.com/default.jpg"); ?>' style="float:left;margin-top: 0px;border:1px solid #ccc;margin-right:5px;" alt="" />
			<h3 style="display:inline;"><?php comment_author_link() ?></h3><br />
			<small><a href="#comment-<?php comment_ID() ?>" alt="permalink" /><?php comment_time('M. j/Y') ?>/<?php comment_time() ?></a> <?php edit_comment_link('e','',''); ?></small>
			<?php if ($comment->comment_approved == '0') : ?>
			<em>Your comment is awaiting moderation.</em>
			<?php endif; ?>
			
			<div style="margin-top:10px;">
			<?php comment_text() ?>
			</div>
		</li>
		<br />

	<?php endforeach; /* end for each comment */ ?>

	</ol>

 <?php else : // this is displayed if there are no comments so far ?>
	</ol>

  <?php if ('open' == $post-> comment_status) : ?> 
	<div style="text-align:center"><h1 style="color:#999;margin-bottom:30px;">NO COMMENTS YET</h1></div>
		<!-- If comments are open, but there are no comments. -->
		
	 <?php else : // comments are closed ?>
		<!-- If comments are closed. -->
		<p class="nocomments">Comments are closed.</p>
		
	<?php endif; ?>
<?php endif; ?>

<ol class="commentlist" id="commentlist">
<a name="viewtrackbacks"></a>
                <?php
                $mytotal_count = $wpdb->get_var("SELECT COUNT(comment_ID) FROM $wpdb->comments WHERE comment_post_ID = '$post->ID' AND comment_approved = '1' AND comment_type != ''");
                if ($comments && $mytotal_count > 0) {
                ?>
                <div id="showpings">
                <h3><b>Pingbacks/Trackbacks</b></h3>
		<br />
                <ol style="list-style-type:none;">
                <div id="thepings">
                <?php $count_pings = 1; foreach ($comments as $comment) { ?>
                <? if ($comment->comment_type == "trackback" || $comment->comment_type == "pingback" || ereg("<pingback />", $comment->comment_content) || ereg("<trackback />", $comment->comment_content)) { ?>

                                <li class="item" id="comment-<?php comment_ID() ?>">
                                        <a name="comment-<?php comment_ID() ?>"></a>
                                        <?php if (function_exists('comment_favicon')) { ?><span class="favatar"><?php comment_favicon(); ?></span><?php } ?>

                                        <span class="commentauthor"><?php comment_author_link() ?></span>
                                        <small class="commentmetadata"><span class="pingtype"><div style="margin-top: 0px;"><?php comment_type(); ?></span> on <a href="#comment-<?php comment_ID() ?>" title="<?php if (function_exists('time_since')) { $comment_datetime = strtotime($comment->comment_date); echo time_since($comment_datetime) ?> ago<?php } else { ?>Permalink to Comment<?php } ?>"><?php comment_date('M jS, Y') ?> at <?php comment_time() ?></a> <?php edit_comment_link('edit','',''); ?></div></small>
                                </li><br />

                        <?php } } echo "</div>"; }/* end for each comment */ ?>
                        </div>
                        </ol>


<div id="comment_loading" style="display:none;margin-left: 20px;margin-top: 5px;"><img src="/wp-content/themes/balance/images/snake.gif" alt="" /></div>
<div id="errors" style="display:none">There was an error with your comment -- sorry dude.</div>

<?php if ('open' == $post-> comment_status) : ?>

<a name="postcomment"></a>
<div id="theform">
<div class="rbtop"><div></div></div>
<div style="width:540px; margin: 0 auto;">
<div style="float:right;"><?php include('searchform.php'); ?></div>
<h3 style="color:#fff;">Reply to this entry</h3>
<br />
<?php if ( get_option('comment_registration') && !$user_ID ) : ?>
<p>You must be <a href="<?php echo get_option('siteurl'); ?>/wp-login.php?redirect_to=<?php the_permalink(); ?>">logged in</a> to post a comment.</p>
<?php else : ?>

<form id="commentform" onsubmit="new Ajax.Updater({success:'commentlist'}, '<?php bloginfo('stylesheet_directory') ?>/ajax_comments.php', {asynchronous:true, evalScripts:true, insertion:Insertion.Bottom, onComplete:function(request){complete(request)}, onFailure:function(request){failure(request)}, onLoading:function(request){loading()}, parameters:Form.serialize(this)}); return false;">

<?php if ( $user_ID ) : ?>

<p>Logged in as <a href="<?php echo get_option('siteurl'); ?>/wp-admin/profile.php"><?php echo $user_identity; ?></a>. <a href="<?php echo get_option('siteurl'); ?>/wp-login.php?action=logout" title="<?php _e('Log out of this account') ?>">Logout &raquo;</a></p>

<?php else : ?>

<p><input type="text" name="author" id="author" value="<?php echo $comment_author; ?>" size="22" tabindex="1" />
<label for="author"><small>Name <?php if ($req) _e('(required)'); ?></small></label></p>

<p><input type="text" name="email" id="email" value="<?php echo $comment_author_email; ?>" size="22" tabindex="2" />
<label for="email"><small>Mail (will not be published) <?php if ($req) _e('(required)'); ?></small></label></p>

<p><input type="text" name="url" id="url" value="<?php echo $comment_author_url; ?>" size="22" tabindex="3" />
<label for="url"><small>Website</small></label></p>

<?php endif; ?>

<div id="formlinks" style="display:inline">
<p><textarea name="comment" id="comment" cols="50" rows="10" tabindex="4"></textarea></p>

<p style="float:right;"><input name="submit" type="submit" id="submit" tabindex="5" value="Submit Comment" />
<input type="hidden" name="comment_post_ID" value="<?php echo $id; ?>" />
</p>
<h3 style="margin-top:40px;color:#fff;margin-bottom:15px;">Further Options</h3>
<?php do_action('comment_form', $post->ID); ?>

</form>
</div>

<div id="singlenav">
<p style="float:left;"><?php previous_post('%','<img src="/wp-content/themes/balance/images/prev.jpg" align="absmiddle" style="padding-bottom:2px;border:0px;" alt="" />&nbsp;&nbsp;Previous', 'no'); ?></p>
<p style="float:right;"><?php next_post('%','Next&nbsp;&nbsp;<img src="/wp-content/themes/balance/images/next.jpg" align="absmiddle" style="padding-bottom:2px;border:0px;" alt="" />','no') ?></p>
<div class="clear:both;"></div>
</div>

</div> <!-- /width: 540px -->
<div class="rbbot"><div></div></div>
</div> <!-- /theform -->

<?php endif; // If registration required and not logged in ?>

<?php endif; // if you delete this the sky will fall on your head ?>

<br/><br/>
</div>
