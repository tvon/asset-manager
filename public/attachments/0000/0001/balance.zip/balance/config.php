<?php
// Category for asides
$asides=3;
?>
