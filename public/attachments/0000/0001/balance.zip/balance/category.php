<?php include('header2.php'); ?>
<div id="pagepage">

<?php if (have_posts()) : ?>
 <?php while (have_posts()) : the_post(); ?>
 <h3 style="display:inline;"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3> <h4 style="margin-left:10px;display:inline;"><?php comments_popup_link('0', '1', '%' ) ?> </h4> <?php edit_post_link("(e)", "", ""); ?>
<div style="margin-top:-2px;"><small><?php the_time('F j, Y'); ?></small></div>

<div style=" padding-top:7px;padding-bottom:17px;">
<div id="recententrycomlink">
<?php the_content('Read More'); ?>
</div>
</div>

 <?php endwhile; ?>
 <?php else : ?>
 <!-- no posts -->
 <div class="nonfeature">
 <h2>Sorry, no posts were found</h2>
 </div><?php endif; ?>

<p style="float:left;"><?php posts_nav_link('','','&laquo; Previous Entries') ?></p>
<p style="float:right;"><?php posts_nav_link('','Next Entries &raquo;','') ?></p>
</div> <!-- /sidenotes -->
<br />

<div id="midbanner">
<div style="width:540px;margin: 0 auto; padding-top:18px;">
        <div style="float:right;">
        <?php include('searchform.php'); ?>
        </div>
        <h2 style="font-weight:normal;"></h2>
</div>
</div>


<div id="pagepage" style="margin-top:20px; margin-bottom:20px;">

<?php include('section2.php'); ?>

<div style="clear:both;"></div>

</div> <!-- /mainpage -->

<?php get_footer(); ?>
