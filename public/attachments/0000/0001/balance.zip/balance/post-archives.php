<?php
/*
	Template name: Post Archives
*/
?>
<?php get_header(); ?>
<div id="pagepage">

<?php /* Counts the posts, comments and categories on your blog */
	$numposts = $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->posts WHERE post_status = 'publish'");
	if (0 < $numposts) $numposts = number_format($numposts); 
	
	$numcomms = $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->comments WHERE comment_approved = '1'");
	if (0 < $numcomms) $numcomms = number_format($numcomms);
	
	$numcats = $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->categories");
	if (0 < $numcats) $numcats = number_format($numcats);
?>


			<h2>Archives</h2>
<p>This is the frontpage of the <?php bloginfo('name'); ?> archives. Currently the archives are spanning <?php echo $numposts; ?> posts and <?php echo $numcomms; ?> comments, contained within the meager confines of <?php echo $numcats; ?> categories. Through here, you will be able to move down into the archives by way of time or category. If you are looking for something specific, perhaps you should try the search on the sidebar.</p>
<br />

			<?php af_ela_super_archive('num_entries=1&num_comments=1&number_text=<span>%</span>&comment_text=<span>%</span>&closed_comment_text=<span>-</span>&selected_text='.urlencode('')); ?>


			<div style='clear: both;'></div>

			<div style="height:30px;"></div>
</div>

<div id="midbanner">
<div style="width:540px;margin: 0 auto; padding-top:18px;">
        <div style="float:right;">
        <?php include('searchform.php'); ?>
        </div>
        <h2 style="font-weight:normal;">Notes</h2>
</div>
</div>


<div id="pagepage" style="margin-top:20px; margin-bottom:20px;">

<?php include('section2.php'); ?>

</div>

<div style="clear:both;"></div>

<br /><br />
<?php get_footer(); ?>
