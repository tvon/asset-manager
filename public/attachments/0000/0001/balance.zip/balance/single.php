<?php include('header2.php'); ?>

<div id="mainpage">
 <?php if (have_posts()) : ?>
 <?php while (have_posts()) : the_post(); ?>

<div id="topdown" style="float:right;">
<a href="#comments"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/down.png" alt="" style="border:0px;" /></a>
</div>
 <h1><?php the_title(); ?></h1>

<div id="maincontent" class="singlemaincontent">
 <?php the_content(''); ?>
</div>

 <div style="clear:both"></div>

</div>

<div id="singlemid">
<div class="rbtop"><div></div></div>
<div style="width:540px;margin: 0 auto; padding-top:0px;">

<div style="float:right;width:250px;">
<h2>Tags</h2>
<br />
<?php UTW_ShowTagsForCurrentPost("commalist"); ?>
</div>

<h2>Information</h2>
<br />
Author: <?php the_author_posts_link('namefl'); ?><br />
Posted: <?php the_time('F j, Y'); ?><br />
Time: <?php the_time(); ?><br />
<a href="<?php trackback_url() ?>" title="Copy this URI to trackback this entry.">Trackback URL</a></span><br />
<?php edit_post_link(); ?>
<div style="clear:both;"></div>
</div>
<div class="rbbot"><div></div></div>
</div>

<div id="comments">
<?php comments_template(); ?>
</div>

 <?php endwhile; ?>
 <?php else : ?>                                
 <!-- no posts -->                                
 <div class="nonfeature">                                
 <h2>Sorry, no posts were found</h2>                                
 </div><?php endif; ?>
