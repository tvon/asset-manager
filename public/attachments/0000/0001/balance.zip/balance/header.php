<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<?php include('config.php'); ?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include('built-in.php'); ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title><?php bloginfo('name'); ?></title>

<script type="text/javascript">
	mypage=unescape(window.location.href);
	mypage=mypage.substr(mypage.lastIndexOf('com')+3)
</script>

<!-- feeds -->
<link rel="alternate" type="text/xml" title="RDF" href="<?php bloginfo('rdf_url'); ?>" />
<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="alternate" type="text/xml" title="RSS .92" href="<?php bloginfo('rss_url'); ?>" />
<link rel="alternate" type="application/atom+xml" title="Atom 0.3" href="<?php bloginfo('atom_url'); ?>" />
<!-- /feeds -->

<!-- styles -->
<link rel="stylesheet" href="<?php bloginfo('stylesheet_directory'); ?>/style.css" />
<link rel="stylesheet" type="text/css" media="screen" href="<?php bloginfo('stylesheet_directory'); ?>/livesearch.css" />
<!-- /styles -->

<!-- javascript -->
<script src="<?php bloginfo('stylesheet_directory'); ?>/js/prototype.js" type="text/javascript"></script>
<script src="<?php bloginfo('stylesheet_directory'); ?>/js/scriptaculous.js" type="text/javascript"></script>
<script src="<?php bloginfo('stylesheet_directory'); ?>/js/ajax_comments.js" type="text/javascript"></script>
<script src="<?php bloginfo('stylesheet_directory'); ?>/js/combo.js" type="text/javascript"></script>
<script src="<?php bloginfo('stylesheet_directory'); ?>/js/browserdetect.js" type="text/javascript"></script>
<script src="<?php bloginfo('stylesheet_directory'); ?>/js/cookies.js" type="text/javascript"></script>
<!-- /javascript -->

<script type="text/javascript">//<![CDATA[
	<?php include "livesearch.js.php"; ?>
//]]></script>

<?php wp_head(); ?>

<?php include('browser_detection.php'); ?>

<?php if ( find('MSIE') ) { ?>
	<link rel="stylesheet" href="<?php bloginfo('stylesheet_directory'); ?>/style_ie.css" />
<?php } ?>

<script type="text/javascript">
window.onload=function(){
	liveSearchInit();
}
</script>

</head>
<body>
<?php if ( find('MSIE') ) { ?>
	<div style="width:576px; text-align:center; background-color: #eee; border-bottom:1px solid #ddd;line-height:18pt;margin:0 auto;"><h2>Thought Mechanics doesn\'t support IE<br /> do yourself a favor and <a href="http://www.browsehappy.com">browse happy</a><h2></div>
<?php } ?>
<p style="display:inline;"><a id="top"></a></p>

<script type="text/javascript">
<!-- 
//<![CDATA[
var now = new Date();
// fix the bug in Navigator 2.0, Macintosh
fixDate(now);
now.setTime(now.getTime() + 1 * 24 * 60 * 60 * 1000);

var mynav = getCookie("navigation");
if (mynav != 1 && browser != 'Opera') {
	document.write('<div id="navigation" style="display:none;">');
} else {
	document.write('<div id="navigation">');
}
//]]>
//-->
</script>
<script type="text/javascript">
<!-- 
//<![CDATA[
if (browser != 'Opera') {
	document.write('<div id="deactivate">');
	document.write('<h2>');
} else {
	document.write('<div id="deactivateopera">');
	document.write('<h2 style="display:none;">');
}
//]]>
//-->
</script>
<h2>
	<a href="#top" onclick="Effect.SlideUp('navigation', {duration: 1.5});document.getElementById('navlink').style.display='inline';document.getElementById('nownavigating').style.display='none';setCookie('navigation',null,now,mypage);">deactivate</a>
</h2>
<script type="text/javascript">
<!--
//<![CDATA[
document.write('</div>');
//]]>
//-->
</script>
<div style="padding:15px;">

<div id="rightside">
<h3 style="color:#fff;margin-bottom:5px;">Meta</h3>
<div id="meta">
<a title="RDF" href="<?php bloginfo('rdf_url'); ?>">RDF</a><br />
<a title="RSS 2.0" href="<?php bloginfo('rss2_url'); ?>">RSS</a><br />
<a title="Atom 0.3" href="<?php bloginfo('atom_url'); ?>">Atom 0.3</a><br />
<a href="http://validator.w3.org/check?uri=referer">XHTML</a><br />
<a href="http://jigsaw.w3.org/css-validator/check/referer">CSS</a><br />
<?php wp_register('',''); ?>
<br /><br />
Design by Thought Mechanics<br />
Powered by <a href="http://www.wordpress.org">Wordpress <?php bloginfo('version'); ?></a><br />
Thought Mechanics &copy; 2005-2006
</div>

<br />
<h3 style="color:#fff;margin-bottom:5px;">Navigation</h3>
<div id="siteinfo">
<ul style="list-style-type:none; text-transform: lowercase;">
<?php wp_list_pages('sort_column=menu_order&depth=1&title_li='); ?>
</ul>
</div>

<br /><br />

</div> <!-- /rightside -->

<div style="width:273px;"> <!-- leftside width -->
<h3 style="color:#fff;margin-bottom:5px;">Comments</h3>
<div class="recent">
<?php get_recent_comments(4, 10, '', '<br /><br />', true); ?>
</div>

<h3 style="color:#fff;margin-bottom:5px;">Previously</h3>
<div id="navprevious">
<?php
 query_posts('cat=-'.$asides.'&posts_per_page=5');
$num=0;
 ?>
 <?php if (have_posts()) : ?>
 <?php while (have_posts()) : the_post(); ?>
<?php if ($num < 1) {$num++;continue;} ?>
 <a style="color:#fff; font-weight:bold;" onmouseover="this.style.color='#6699cc';" onmouseout="this.style.color='#ffffff';" href="<?php the_permalink(); ?>"><?php the_title(); ?></a><br />
 <span style="color: #999; font-weight:normal;"><?php the_time('F j, Y'); ?> |</span> <?php comments_popup_link('0 Comments', '1 Comment', '% Comments' ) ?>
<br /><br />
 <?php endwhile; ?>
 <?php else : ?>
 <!-- no posts -->
 <div class="nonfeature">
 <h2>Sorry, no posts were found</h2>
 </div><?php endif; ?>
</div> <!-- /navprevious -->

</div> <!-- /leftside width -->
</div> <!-- /padding -->
<script type="text/javascript">
<!-- 
//<![CDATA[
document.write('</div>'); 
//]]>
//-->
</script>

<div id="navbar">
<div id="navlink">
<h2>
	<script type="text/javascript">if (mypage.indexOf("#")==-1) {mypage=mypage+"#top";}</script>
	<a href="#top" onclick="Effect.SlideDown('navigation', {duration: 1.5});document.getElementById('navlink').style.display='none';document.getElementById('nownavigating').style.display='inline';setCookie('navigation',1,now,mypage);">navigation</a>
</h2>
</div>
<div id="nownavigating" style="display:none;">
	<div style="color: #999;font-weight:normal;">you are now</div><h2> navigating</h2>
</div>

<div id="logo">
	<h2><a href="<?php bloginfo('url'); ?>"><?php bloginfo('name'); ?></a></h2>
</div>
</div>
