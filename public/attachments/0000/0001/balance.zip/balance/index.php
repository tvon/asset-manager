<?php include('config.php'); ?>
<?php if ($_GET['tag'] || $_GET['s']) { ?>
<?php include('header2.php'); ?>
<div id="pagepage">

<?php if (have_posts()) : ?>
 <?php while (have_posts()) : the_post(); ?>
 <h3 style="display:inline;"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3> <h4 style="margin-left:10px;display:inline;"><?php comments_popup_link('0', '1', '%' ) ?> </h4> <?php edit_post_link("(e)", "", ""); ?>
<div style="margin-top:-2px;"><small><?php the_time('F j, Y'); ?></small></div>

<div style=" padding-top:7px;padding-bottom:17px;">
<?php the_excerpt('Read More'); ?>
</div>

 <?php endwhile; ?>
 <?php else : ?>
 <!-- no posts -->
 <div class="nonfeature">
 <h2>Sorry, no posts were found</h2>
 </div><?php endif; ?>
</div> <!-- /sidenotes -->

<p style="float:left;"><?php previous_post('&laquo; %','','yes') ?></p>
<p style="float:right;"><?php next_post(' % &raquo;','','yes') ?></p>

<div id="midbanner">
<div style="width:540px;margin: 0 auto; padding-top:18px;">
        <div style="float:right;">
        <?php include('searchform.php'); ?>
        </div>
        <h2 style="font-weight:normal;"></h2>
</div>
</div>


<div id="pagepage" style="margin-top:20px; margin-bottom:20px;">

<?php include('section2.php'); ?>

<div style="clear:both;"></div>

</div> <!-- /pagepage -->

<?php } else { ?>
<?php get_header(); ?>
<div id="mainpage">
<?php
query_posts('cat=-'.$asides.'&posts_per_page=1');
 ?>
 <?php if (have_posts()) : ?>
 <?php while (have_posts()) : the_post(); ?>
<div style="margin-top:5px;padding-left:30px;float:right;"><h2><?php comments_popup_link('0', '1', '%' ) ?> <?php edit_post_link("(e)", "", ""); ?></h2></div>
 <h1><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
<div id="maincontent" class="maincontent">
 <?php the_content('(Read more)'); ?>
 </div>

 <?php endwhile; ?>
 <?php else : ?>
 <!-- no posts -->
 <div class="nonfeature">
 <h2>Sorry, no posts were found</h2>
 </div><?php endif; ?>

<div style="clear:both;"></div>

<script type="text/javascript">
<!--
//<![CDATA[
var now = new Date();
// fix the bug in Navigator 2.0, Macintosh
fixDate(now);
now.setTime(now.getTime() + 1 * 24 * 60 * 60 * 1000);

var mylongview = getCookie("longview");
if (mylongview != 1) {
        document.write('<div id="longview" style="display:none;">');
} else {
        document.write('<div id="longview">');
}
//]]>
//-->
</script>
</div>


	<script type="text/javascript">
		if (mylongview==1) {
		new Ajax.Updater({success:'longview'}, 'http://<?php echo $_SERVER['HTTP_HOST'] ?>/wp-content/themes/balance/longview.php',{asynchronous:true}); }</script>

<div id="loader" style="display:none;">
<img style="border:0px;" src="/wp-content/themes/balance/images/snake.gif" alt="" />
</div>

<div id="announce">
<div style="float:right;">Announcements and whatever go here...</div>
<script type="text/javascript">
<!--
//<![CDATA[
if (mylongview==1) {
	document.write('<div id="lview" style="float:left; display:none;">');
} else {
	document.write('<div id="lview" style="float:left">');
}
//]]>
//-->
</script>

<a href="#top" onclick="new Ajax.Updater({success:'longview'}, 'http://<?php echo $_SERVER['HTTP_HOST'] ?>/wp-content/themes/balance/longview.php',{asynchronous:true, onLoading:function(request){Element.show('loader')}, onComplete:function(request){Element.hide('loader')}}); Effect.BlindDown('longview', {duration: 1.5});Element.hide('lview');Element.show('sview');setCookie('longview',1,now,mypage);">Long View</a>
</div> 
<script type="text/javascript">
<!--
//<![CDATA[
if (mylongview==1) {
	document.write('<div id="sview" style="float:left">');
} else {
	document.write('<div id="sview" style="float:left; display:none;">');
}
//]]>
//-->
</script>
<p style="display:inline;"><a href="#top" onclick="Effect.BlindUp('longview', {duration: 1.5});Element.hide('sview');Element.show('lview');setCookie('longview',0,now,mypage);">Short View</a></p>
<script type="text/javascript">
<!--
//<![CDATA[
document.write('</div>');
//]]>
//-->
</script>
<div style="clear:both;"></div>
<script type="text/javascript">
<!--
//<![CDATA[
document.write('</div>');
//]]>
//-->
</script>

<?php include('section2.php'); ?>

<div style="clear:both;"></div>

<script type="text/javascript">
<!--
//<![CDATA[
document.write('</div>');
//]]>
//-->
</script>

<div id="midbanner">
<div style="width:540px;margin: 0 auto; padding-top:18px;">
	<div style="float:right;">
	<?php include('searchform.php'); ?>
	</div>
	<h2 style="font-weight:normal;">Notes</h2>
</div>
</div>

<div id="sidenotes">
<?php
 query_posts('cat='.$asides.'&posts_per_page=5');
 ?>
 <?php if (have_posts()) : ?>
 <?php while (have_posts()) : the_post(); ?>
 <h3 style="display:inline;"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3> <h4 style="margin-left:10px;display:inline;"><?php comments_popup_link('0', '1', '%' ) ?> </h4> <?php edit_post_link("(e)", "", ""); ?>
<div style="margin-top:-2px;"><small><?php the_time('F j, Y'); ?></small></div>

<div style=" padding-top:7px;padding-bottom:17px;">
<?php the_content('Read More'); ?>
</div>

 <?php endwhile; ?>
<a href="/category/asides">Get More</a>
<br /><br />
 <?php else : ?>
 <!-- no posts -->
 <div class="nonfeature">
 <h2>Sorry, no posts were found</h2>
 </div><?php endif; ?>
</div> <!-- /sidenotes -->

<?php } ?>

<?php get_footer(); ?>
