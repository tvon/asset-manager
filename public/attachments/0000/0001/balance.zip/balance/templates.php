<?php /*
			 Template Name: Templates
		*/
?>

<?php get_header(); ?>

<!-- Begin #content -->
<div id="pagepage">

<h1>Wordpress Themes</h1>

<div id="maincontent">
<br />
If you have problems, questions or comments about a specific template, please go to the <a href="http://www.flickr.com/groups/tmblog/">discussion board</a>.
<br /><br /><br />

<img src="/templatefiles/images/squible.jpg" style="border:1px solid #D5D7DB; float: right; vertical-align: center;" alt=""  />
<b>name</b>: Squible<br /><b>description</b>: Wordpress theme<br /><b>download</b>: <a href="http://www.squible.com/squible">squible.com</a>
<br />Stats not available for this theme

<br /><div style="border-bottom: 0px solid #999;">&nbsp;</div><br />

<img src="/templatefiles/images/a0.jpg" style="border:1px solid #D5D7DB; float: right; vertical-align: center;" alt=""  />
<b>name</b>: Alternate 0<br /><b>description</b>: Wordpress theme<br /><b>download</b>: <a href="/templatefiles/v2.2/download.php?get=alternate0.zip">alternate0.zip</a>
<br />Downloaded (<?php include('http://www.thoughtmechanics.com/templatefiles/counters/alternate0.zip.txt'); ?>) times

<br /><div style="border-bottom: 0px solid #999;">&nbsp;</div><br />

<img src="/templatefiles/images/ph.jpg" style="border:1px solid #D5D7DB; float: right; vertical-align: center;" alt=""  />
<b>name</b>: Photanical<br /><b>description</b>: Wordpress theme<br /><b>download</b>: <a href="/templatefiles/v2.2/download.php?get=photanical.zip">photanical.zip</a>
<br />Downloaded (<?php include('http://www.thoughtmechanics.com/templatefiles/counters/photanical.zip.txt'); ?>) times

<br /><div style="border-bottom: 0px solid #999;">&nbsp;</div><br />

<img src="/templatefiles/images/mp.jpg" style="border:1px solid #D5D7DB; float: right; vertical-align: center;" alt=""  />
<b>name</b>: Minima Plus<br /><b>description</b>: Wordpress theme<br /><b>download</b>: <a href="/templatefiles/v2.2/download.php?get=MinimaPlus.zip">MinimaPlus.zip</a>
<br />Downloaded (<?php include('http://www.thoughtmechanics.com/templatefiles/counters/MinimaPlus.zip.txt'); ?>) times

<br /><div style="border-bottom: 0px solid #999;">&nbsp;</div><br />

<img src="/templatefiles/images/benevolence.jpg" style="border:1px solid #D5D7DB; float: right; vertical-align: center;" alt=""  />
<b>name</b>: Benevolence<br /><b>description</b>: Wordpress theme<br /><b>download</b>: <a href="/templatefiles/v2.2/download.php?get=benevolence.zip">benevolence.zip</a>
<br />Downloaded (<?php include('http://www.thoughtmechanics.com/templatefiles/counters/benevolence.zip.txt'); ?>) times

<br /><div style="border-bottom: 0px solid #999;">&nbsp;</div><br />

<img src="/templatefiles/images/thought.jpg" style="border:1px solid #D5D7DB; float: right; vertical-align: center;" alt=""  />
<b>name</b>: Thought Mechanics<br /><b>description</b>: Wordpress theme<br /><b>download</b>: <a href="/templatefiles/v2.2/download.php?get=thoughtmechanics.zip">zip archive</b></a>
<br />Downloaded (<?php include('http://www.thoughtmechanics.com/templatefiles/counters/thoughtmechanics.zip.txt'); ?>) times

<br /><div style="border-bottom: 0px solid #999;">&nbsp;</div><br />

<img src="/templatefiles/images/bionicjive.jpg" style="border:1px solid #D5D7DB; float: right; vertical-align: center;" alt=""  />
<b>name</b>: Bionic Jive<br /><b>description</b>: Wordpress theme<br /><b>download</b>: <a href="/templatefiles/v2.2/download.php?get=bionicjive.zip">bionicjive.zip</a>
<br />Downloaded (<?php include('http://www.thoughtmechanics.com/templatefiles/counters/bionicjive.zip.txt'); ?>) times

<br /><div style="border-bottom: 0px solid #999;">&nbsp;</div><br />

<img src="/templatefiles/images/conestoga.jpg" style="border:1px solid #D5D7DB; float: right; vertical-align: center;" alt=""  />     
<b>name</b>: Conestoga Street<br /><b>description</b>: Wordpress theme<br /><b>download</b>: <a href="/templatefiles/v2.2/download.php?get=Conestogastreet.zip">Conestogastreet.zip</a>
<br />Downloaded (<?php include('http://www.thoughtmechanics.com/templatefiles/counters/Conestogastreet.zip.txt'); ?>) times

</div>
</div>

<br />
<div id="midbanner">
<div style="width:540px;margin: 0 auto; padding-top:18px;">
        <div style="float:right;">
        <?php include('searchform.php'); ?>
        </div>
        <h2 style="font-weight:normal;">Notes</h2>
</div>
</div>


<div id="pagepage" style="margin-top:20px; margin-bottom:20px;">

<?php include('section2.php'); ?>

</div>

<div style="clear:both;"></div>

<br /><br />
<?php get_footer(); ?>
