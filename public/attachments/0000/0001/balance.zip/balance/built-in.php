<?php
function get_most_commented($no_posts = 5, $before = '<li>', $after = '</li>', $show_pass_post = false) {
        global $wpdb, $tableposts, $tablecomments;
        $request = "SELECT ID, post_title, COUNT($tablecomments.comment_post_ID) AS 'comment_count' FROM $tableposts, $tablecomments WHERE";
        $request .= " $tableposts.ID=$tablecomments.comment_post_ID AND post_status = 'publish'";
        if(!$show_pass_post) { $request .= " AND post_password =''"; }
        $request .= " AND comment_approved = '1' GROUP BY $tablecomments.comment_post_ID ORDER BY comment_count DESC LIMIT $no_posts";
        $posts = $wpdb->get_results($request);
        $output = '';
        foreach ($posts as $post) {
                $post_title = stripslashes($post->post_title);
                $comment_count = $post->comment_count;
                $permalink = get_permalink($post->ID);
                $output .= $before . '<a href="' . $permalink . '" title="' . $post_title.'">' . $post_title . '</a> (' . $comment_count.')' . $after;
        }
        echo $output;
}

function get_recent_comments($no_comments = 5, $comment_lenth = 5, $before = '<li>', $after = '</li>', $show_pass_post = false) {
        global $wpdb, $tablecomments, $tableposts;
        $request = "SELECT ID, comment_ID, comment_content, comment_author, comment_type FROM $tableposts, $tablecomments WHERE $tableposts.ID=$tablecomments.comment_post_ID AND post_status = 'publish' AND comment_type = ''";
        if(!$show_pass_post) { $request .= "AND post_password ='' "; }
        $request .= "AND comment_approved = '1' ORDER BY $tablecomments.comment_date DESC LIMIT $no_comments";
        $comments = $wpdb->get_results($request);
        $output = '';
	if (!$comments) {return;}
	$first=1;
        foreach ($comments as $comment) {
                $comment_author = stripslashes($comment->comment_author);
                $comment_content = strip_tags($comment->comment_content);
                $comment_content = stripslashes($comment_content);
                $words=split(" ",$comment_content);
                $comment_excerpt = join(" ",array_slice($words,0,$comment_lenth));
                $permalink = get_permalink($comment->ID)."#comment-".$comment->comment_ID;

                	$output .= '<a href="' . $permalink . '">' . $comment_author . '</a>:';
                $output .= ' ' . $comment_excerpt . '...<br /><br />';
            }
        echo $output;
}

function my_comments_popup_link($zero='No Comments', $one='1 Comment', $more='% Comments', $CSSclass='', $none='Comments Off') {
        global $id, $wpcommentspopupfile, $wpcommentsjavascript, $post, $wpdb;
        global $comment_count_cache;

        if (! is_single() && ! is_page()) {
        if ( !isset($comment_count_cache[$id]) )
                $comment_count_cache[$id] = $wpdb->get_var("SELECT COUNT(comment_ID) FROM $wpdb->comments WHERE comment_post_ID = $id AND comment_approved = '1';");

        $number = $comment_count_cache[$id];

        if (0 == $number && 'closed' == $post->comment_status && 'closed' == $post->ping_status) {
                echo $none;
                return;
        } else {
                if (!empty($post->post_password)) { // if there's a password
                        if ($_COOKIE['wp-postpass_'.COOKIEHASH] != $post->post_password) {  // and it doesn't match the cookie
                                echo('Enter your password to view comments');
                                return;
                        }
                }
                echo '<a class="commentslink" href="';
                if ($wpcommentsjavascript) {
                        if ( empty($wpcommentspopupfile) )
                                $home = get_settings('home');
                        else
                                $home = get_settings('siteurl');
                        echo $home . '/' . $wpcommentspopupfile.'?comments_popup='.$id;
                        echo '" onclick="wpopen(this.href); return false"';
                } else { // if comments_popup_script() is not in the template, display simple comment link
                        if ( 0 == $number )
                                echo get_permalink() . '#respond';
                        else
                                comments_link();
                        echo '"';
                }
                if (!empty($CSSclass)) {
                        echo ' class="'.$CSSclass.'"';
                }
                echo ' title="' . sprintf( __('Comment on %s'), $post->post_title ) .'">';
                comments_number($zero, $one, $more, $number);
                echo '</a>';
        }
        }
}

?>
