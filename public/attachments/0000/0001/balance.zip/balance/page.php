<?php include('header2.php'); ?>
<div id="pagepage">
 <?php if (have_posts()) : ?>
 <?php while (have_posts()) : the_post(); ?>

<div style="float:right;"><?php edit_post_link(); ?></div>
 <h1><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
<div id="maincontent" class="maincontent">
 <?php the_content('Read More'); ?>
 </div>

 <?php endwhile; ?>
 <?php else : ?>
 <!-- no posts -->
 <div class="nonfeature">
 <h2>Sorry, no posts were found</h2>
 </div><?php endif; ?>

</div>

<div id="midbanner">
<div style="width:540px;margin: 0 auto; padding-top:18px;">
        <div style="float:right;">
        <?php include('searchform.php'); ?>
        </div>
        <h2 style="font-weight:normal;"></h2>
</div>
</div>


<div id="pagepage" style="margin-top:20px; margin-bottom:20px;">

<?php include('section2.php'); ?>

<div style="clear:both;"></div>

</div> <!-- /mainpage -->

<?php get_footer(); ?>
