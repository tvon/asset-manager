<?php include('config.php'); ?>
<div id="section2">

<div id="recentloader" style="float:right;display:none;">
<img style="border:0px;" src="/wp-content/themes/balance/images/snake.gif" alt="" />
</div>
<div id="recentwork">
</div>
<div style="float:right;width:250px;">
<h3>Flickr</h3>
<br />
<div id="flickr">
<?php get_flickrRSS(); ?>
</div>
</div>

<?php
query_posts('cat=-'.$asides.'&posts_per_page=5');
$num=0;
 ?>
<div id="sec2entries">
 <?php if (have_posts()) : ?>
<h3>Recent Entries</h3>
<br />
 <?php while (have_posts()) : the_post(); ?>
<?php if ($num < 1) {$num++;continue;} ?>
 <h4><a style="border:0px;" href="<?php the_permalink(); ?>"><?php the_title(); ?></a> <?php edit_post_link("(e)", "", ""); ?></h4>
 <div class="postmeta" style="margin:0px">
 <?php the_time('F j, Y'); ?> | <?php comments_popup_link('0 comments', '1 comment', '% comments' ) ?>
 </div>
<br />
 <?php endwhile; ?>
 <?php else : ?>
 <!-- no posts -->
 <div class="nonfeature">
 <h2>Sorry, no posts were found</h2>
 </div><?php endif; ?>
</div>

</div> <!-- /section2 -->
