<?php include('config.php'); ?>
<?php
require('../../../wp-blog-header.php');
query_posts('cat=-'.$asides.'&posts_per_page=5');
$first=0;
 ?>
<br /><br /><br />
 <?php if (have_posts()) : ?>
 <?php while (have_posts()) : the_post(); ?>
<?php if (!$first) { $first++; continue;} ?>
<div style="margin-bottom:60px;">
<div style="margin-top:5px;padding-left:30px;float:right;"><h2><?php comments_popup_link('0', '1', '%' ) ?> <?php edit_post_link("(e)", "", ""); ?></h2></div>
 <h1><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
<div id="maincontent" class="maincontent">
 <?php the_content('(Read more)'); ?>
 </div>
</div>

 <?php endwhile; ?>
 <?php else : ?>
 <!-- no posts -->
 <div class="nonfeature">
 <h2>Sorry, no posts were found</h2>
 </div><?php endif; ?>
