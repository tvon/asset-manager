<div id="lowbanner">
<div style="width:540px;margin: 0 auto; padding-top:11px;">
<div style="float:right; padding-top:3px; text-align:left; width:230px;">
<a title="RSS" type="application/rss+xml" href="<?php bloginfo('rss2_url'); ?>"><img src="/wp-content/themes/balance/images/rss_icon.png" alt="rss" style="float:left;padding-right:10px;border:0px;" /></a>
<a href="http://www.wordpressfirewall.com">Wordpress Firewall</a> (<a href="http://www.firewallscript.com">*</a>)<br />
All content, <?php bloginfo('name'); ?>, &copy; 2005-2006
</div>
<a href="#top"><img src="/wp-content/themes/balance/images/top.jpg" alt="top" style="border: 0px;" /></a>
</div>
</div>

</body>
</html>
